package ClassArray;

import java.util.ArrayList;

public class AvtoSalon {
    public static void main(String[] args) {
        Ford fusion=new Ford("Fusion","yas asfalt",2018,1.5);
        Ford explorer=new Ford("Explorer","white",2018,6.6);
        BMW e60=new BMW("E 60","white",2007,5.0);
        BMW f30=new BMW("F 30","qara",2016,3.0);
        BMW e63=new BMW("E 63","black",2007,5.0);
        // Array[] sade
        BMW[] bmwArrayi={e60,f30,e63};
        Ford[] fordArrayi={fusion,explorer};

        // ArrayList<>
        ArrayList<BMW> bmwArrayList=new ArrayList<>();
        bmwArrayList.add(e60);
        bmwArrayList.add(f30);
        bmwArrayList.add(e63);

        ArrayList<Ford> fordArrayList=new ArrayList<>();
        fordArrayList.add(fusion);
        fordArrayList.add(explorer);
    }
}
