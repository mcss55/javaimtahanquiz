package ClassArray;

public class BMW {
    public String model;
    public String reng;
    public int il;
    public double mator;

    public BMW(String model, String reng, int il, double mator) {
        this.model = model;
        this.reng = reng;
        this.il = il;
        this.mator = mator;
    }
}
