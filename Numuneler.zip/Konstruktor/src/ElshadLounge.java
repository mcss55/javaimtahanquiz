import java.util.ArrayList;

public class ElshadLounge {
    public static void main(String[] args) {
        ArrayList<String> menu=new ArrayList<>();
        menu.add("chay");
        menu.add("su");
        menu.add("kola");
        menu.add("semichka");
        Lounge elshadinObyekti=new Lounge(menu,"Elsad Lounge","Ehmedli","+994505555555",15,5);
        System.out.println(elshadinObyekti.getLounge_masa_sayi());
        elshadinObyekti.setLounge_masa_sayi(elshadinObyekti.getLounge_masa_sayi()+50);
        System.out.println(elshadinObyekti.getLounge_masa_sayi());
        elshadinObyekti.getMenu().add("ayran");
        System.out.println(elshadinObyekti.getMenu());
        elshadinObyekti.setLounge_elage("+9940552867086");
        System.out.println(elshadinObyekti.getLounge_elage());
        System.out.println(elshadinObyekti.getLounge_kabinet_sayi());
        elshadinObyekti.setLounge_kabinet_sayi(elshadinObyekti.getLounge_kabinet_sayi()*200);
        System.out.println(elshadinObyekti.getLounge_kabinet_sayi());
    }
}
