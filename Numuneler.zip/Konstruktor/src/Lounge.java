import java.util.ArrayList;

public class Lounge {
    private ArrayList<String> menu;
    private String lounge_name;
    private String lounge_unvan;
    private String lounge_elage;
    private int lounge_masa_sayi;
    private int lounge_kabinet_sayi;

    public Lounge(ArrayList<String> menu, String lounge_name, String lounge_unvan, String lounge_elage, int lounge_masa_sayi, int lounge_kabinet_sayi) {
        this.menu = menu;
        this.lounge_name = lounge_name;
        this.lounge_unvan = lounge_unvan;
        this.lounge_elage = lounge_elage;
        this.lounge_masa_sayi = lounge_masa_sayi;
        this.lounge_kabinet_sayi = lounge_kabinet_sayi;
    }

    public ArrayList<String> getMenu() {
        return menu;
    }

    public void setMenu(ArrayList<String> menu) {
        this.menu = menu;
    }
    public String getLounge_name() {
        return lounge_name;
    }

    public void setLounge_name(String lounge_name) {
        this.lounge_name = lounge_name;
    }

    public String getLounge_unvan() {
        return lounge_unvan;
    }

    public void setLounge_unvan(String lounge_unvan) {
        this.lounge_unvan = lounge_unvan;
    }

    public String getLounge_elage() {
        return lounge_elage;
    }

    public void setLounge_elage(String lounge_elage) {
        this.lounge_elage = lounge_elage;
    }

    public int getLounge_masa_sayi() {
        return lounge_masa_sayi;
    }

    public void setLounge_masa_sayi(int lounge_masa_sayi) {
        this.lounge_masa_sayi = lounge_masa_sayi;
    }

    public int getLounge_kabinet_sayi() {
        return lounge_kabinet_sayi;
    }

    public void setLounge_kabinet_sayi(int lounge_kabinet_sayi) {
        this.lounge_kabinet_sayi = lounge_kabinet_sayi;
    }
}
