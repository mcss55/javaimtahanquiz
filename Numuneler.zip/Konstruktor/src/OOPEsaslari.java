public class OOPEsaslari {
    public static void main(String[] args) {

    }

}
