public class Sual4 {
    public static void main(String[] args) {
        int reqem = 5;
        float onluqreqem = 5.99f;
        byte bit=127;
        long uzunreqem=519849848;
        char herf = 'D';
        boolean yoxlama = true;
        String ad = "Emil";
    }
}
