package abstarct;

public class BMW extends Mashin {

//    Mashin masin=new Mashin("IUS2198ASJDHIOSA",3);

    public BMW(String vin,int buraxilish){
        super(vin,buraxilish);
    }

    @Override
    public String vinKod() {
        return vinKod;
    }

    @Override
    int buraxilishIli() {
        return buraxilishIli;
    }
}
