package abstarct;

public class E60 {
    public static void main(String[] args) {
        BMW e60=new BMW("HSD65IUO12HSASD",2007);
        System.out.println(e60.buraxilishIli());

    }
}
