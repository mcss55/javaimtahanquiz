package abstarct;

public abstract class Mashin {
    String vinKod;
    int buraxilishIli;

    public Mashin(String vinKod, int buraxilishIli) {
        this.vinKod = vinKod;
        this.buraxilishIli = buraxilishIli;
    }

    abstract String vinKod();
    abstract int buraxilishIli();
}
