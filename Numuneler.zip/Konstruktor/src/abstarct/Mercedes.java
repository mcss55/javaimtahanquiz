package abstarct;

public class Mercedes extends Mashin{
    public Mercedes(String vin,int buraxilish){
        super(vin,buraxilish);
    }

    @Override
    public String vinKod() {
        return vinKod;
    }

    @Override
    int buraxilishIli() {
        return buraxilishIli;
    }
}
