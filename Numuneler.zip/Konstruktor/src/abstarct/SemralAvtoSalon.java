package abstarct;

public class SemralAvtoSalon {
    public static void main(String[] args) {
        /*
        BMW bmw=new BMW("ASDQW123123ASDASd",2000);
        Ford ford_fusion=new Ford("ASD34235FdsSDF",2021);
        Mercedes mercedes_c230=new Mercedes("SADOI785YIASUDYU",1998);
        */
        Mashin bmw=new BMW("ASDQW123123ASDASd",2000);
        Mashin ford_fusion=new Ford("ASD34235FdsSDF",2021);
        Mashin mercedes_c230=new Mercedes("SADOI785YIASUDYU",1998);
        System.out.println(bmw.vinKod());
        System.out.println(ford_fusion.vinKod());
        System.out.println(mercedes_c230.vinKod());
    }
}
