package accessmodifier;

public class Emil {
    protected String emilinTumusununRengi="red";
}
