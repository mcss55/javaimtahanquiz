package accessmodifier;

public class Ferid {
    public static void main(String[] args) {
        Emil emil=new Emil();
        System.out.println(emil.emilinTumusununRengi);
    }
}
