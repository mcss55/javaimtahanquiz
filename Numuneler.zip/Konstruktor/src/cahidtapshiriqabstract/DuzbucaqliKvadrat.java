package cahidtapshiriqabstract;

public class DuzbucaqliKvadrat  extends  Kvadrat{

    public DuzbucaqliKvadrat(String fiqurunAdi, String fiqurunRengi, int kunc, int a, int b) {
        super(fiqurunAdi, fiqurunRengi, kunc, a, b);
    }
}
