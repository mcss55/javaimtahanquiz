package cahidtapshiriqabstract;

public class DuzbucaqliUcbucaq extends Ucbucaq{

    public DuzbucaqliUcbucaq(String fiqurunAdi, String fiqurunRengi, int kunc, int a, int b) {
        super(fiqurunAdi, fiqurunRengi, kunc, a, b);
    }



}
