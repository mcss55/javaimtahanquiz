package cahidtapshiriqabstract;

public abstract class  Fiqur {

    abstract int kuncSayi();
    abstract String rengi();
    abstract int sahesi();
    abstract String ad();

    public String fiqurunAdi;
    public String fiqurunRengi;
    public int kunc;
    public int a,b;

    public Fiqur(String fiqurunAdi, String fiqurunRengi, int kunc, int a, int b) {
        this.fiqurunAdi = fiqurunAdi;
        this.fiqurunRengi = fiqurunRengi;
        this.kunc = kunc;
        this.a = a;
        this.b = b;
    }
}
