package cahidtapshiriqabstract;

public class Hendese {

    public static void main(String[] args) {
        Ucbucaq duzbucaqliUcbucaq = new Ucbucaq("Duzbucaqli Ucbucaq","mavi",3,1,2);
        Kvadrat duzbucaqliKvadrat = new Kvadrat("Duzbucaqli Kvadrat","sari",4,2,3);
        System.out.println(duzbucaqliKvadrat.fiqurunAdi);
        System.out.println(duzbucaqliUcbucaq.sahesi());
        System.out.println(duzbucaqliUcbucaq.fiqurunAdi + " "+ duzbucaqliUcbucaq.fiqurunRengi);
        System.out.println(duzbucaqliUcbucaq.kuncSayi()*4);
    }

}
