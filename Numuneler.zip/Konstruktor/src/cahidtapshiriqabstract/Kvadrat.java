package cahidtapshiriqabstract;

public class Kvadrat  extends  Fiqur{

    public Kvadrat(String fiqurunAdi, String fiqurunRengi, int kunc, int a, int b) {
        super(fiqurunAdi, fiqurunRengi, kunc, a, b);
    }

    @Override
    int kuncSayi() {
        return 0;
    }

    @Override
    String rengi() {
        return null;
    }

    @Override
    int sahesi() {
        return 0;
    }

    @Override
    String ad() {
        return null;
    }
}
