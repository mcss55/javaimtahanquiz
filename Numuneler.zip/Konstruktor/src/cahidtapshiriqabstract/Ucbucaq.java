package cahidtapshiriqabstract;

public class Ucbucaq extends Fiqur{

    public Ucbucaq(String fiqurunAdi, String fiqurunRengi, int kunc, int a, int b) {
        super(fiqurunAdi, fiqurunRengi, kunc, a, b);
    }

    @Override
    public int kuncSayi(){
       return kunc;
   }

   @Override
    public String rengi(){
       return fiqurunRengi;
   }

   @Override
    public int sahesi(){
       return a*b;
   }

   @Override
    public String ad(){
       return fiqurunAdi;
   }
}
