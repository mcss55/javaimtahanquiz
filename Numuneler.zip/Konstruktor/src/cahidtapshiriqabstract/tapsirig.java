package cahidtapshiriqabstract;

import java.util.Scanner;

public class tapsirig {

    public static void main(String[] args) {

    }
}
