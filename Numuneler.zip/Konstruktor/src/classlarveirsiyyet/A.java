package classlarveirsiyyet;

public class A  {

}
