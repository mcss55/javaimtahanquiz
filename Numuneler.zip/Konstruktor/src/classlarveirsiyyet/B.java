package classlarveirsiyyet;

public class B extends A {
}
