package classlarveirsiyyet;

public class C extends  B{
}
