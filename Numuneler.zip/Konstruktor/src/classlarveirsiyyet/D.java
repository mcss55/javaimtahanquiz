package classlarveirsiyyet;

import java.util.ArrayList;

public class D {
    public static void main(String[] args) {
        A C1 = new C();

    }
}
