public class ifelse {
    public static void main(String[] args) {
        int a=10;
        int b=10;

        if(a>b){
            System.out.println("a b-den big");
        }
        else if(a==b){
            System.out.println("a b ye  = di");
        }
        else{
            System.out.println("a b-den little");
        }


    }
}
