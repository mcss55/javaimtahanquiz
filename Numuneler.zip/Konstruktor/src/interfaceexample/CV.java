package interfaceexample;

public interface CV {
    public void dilSeviyyesi(String dil,int derece);
    public void tecrube(int il);
    public void proqDili(String proqDili);
}
