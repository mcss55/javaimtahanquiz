package interfaceexample;

public class Emil implements CV {
    @Override
    public void dilSeviyyesi(String dil, int derece) {

    }

    @Override
    public void tecrube(int il) {

    }

    @Override
    public void proqDili(String proqDili) {

    }

}
