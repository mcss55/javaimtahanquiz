package semral;

import accessmodifier.*;

public class Magaza{

    public static void main(String[] args) {

        Samsung galaxy = new Samsung("S Duos", "qara","3221em2ke");
        Samsung galaxy2 = new Samsung("Note 10", "ag", "hhsduh324");

        System.out.println(galaxy.adi +" " + galaxy2.reng);

    }
    // 3 param'li mehtod
    //public void hesabla(int a,int b,int c){

    //}
}
