package semral;

public class Samsung extends Telefon {
    public Samsung(String adi, String reng, String imei) {
        super(adi, reng, imei);
    }

    @Override
    public String imeikod() {
        return imei;

    }

    @Override
    public String rengi() {

        return reng;
    }

    @Override
    public String modeli() {
        return adi;
    }

}
