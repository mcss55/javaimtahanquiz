package semral;

public abstract class Telefon {
    public abstract String imeikod();
    public abstract String rengi();
    public abstract String modeli();

    public String adi;
    public String reng;
    public String imei;

    public Telefon(String adi, String reng, String imei) {
        this.adi = adi;
        this.reng = reng;
        this.imei = imei;
    }
}
